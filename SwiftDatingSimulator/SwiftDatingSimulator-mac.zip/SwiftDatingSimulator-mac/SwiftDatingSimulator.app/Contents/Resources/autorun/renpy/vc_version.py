vc_version = 2266
official = True
nightly = False
